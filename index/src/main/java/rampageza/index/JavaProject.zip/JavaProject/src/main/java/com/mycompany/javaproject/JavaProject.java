/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaproject;

/**
 *
 * @author Mathew
 */
public class JavaProject {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
